gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.localVariables = [];
gdjs.Untitled_32sceneCode.idToCallbackMap = new Map();
gdjs.Untitled_32sceneCode.GDCarbonObjects1= [];
gdjs.Untitled_32sceneCode.GDCarbonObjects2= [];
gdjs.Untitled_32sceneCode.GDDarkWoodPlancksBlockObjects1= [];
gdjs.Untitled_32sceneCode.GDDarkWoodPlancksBlockObjects2= [];
gdjs.Untitled_32sceneCode.GDBlueBlockObjects1= [];
gdjs.Untitled_32sceneCode.GDBlueBlockObjects2= [];
gdjs.Untitled_32sceneCode.GDYellowBlockObjects1= [];
gdjs.Untitled_32sceneCode.GDYellowBlockObjects2= [];
gdjs.Untitled_32sceneCode.GDCharcoalBlockObjects1= [];
gdjs.Untitled_32sceneCode.GDCharcoalBlockObjects2= [];
gdjs.Untitled_32sceneCode.GDGreyBlockObjects1= [];
gdjs.Untitled_32sceneCode.GDGreyBlockObjects2= [];
gdjs.Untitled_32sceneCode.GDRedBlockObjects1= [];
gdjs.Untitled_32sceneCode.GDRedBlockObjects2= [];
gdjs.Untitled_32sceneCode.GDGame_9595Over_9595TextObjects1= [];
gdjs.Untitled_32sceneCode.GDGame_9595Over_9595TextObjects2= [];
gdjs.Untitled_32sceneCode.GDCoralBlockObjects1= [];
gdjs.Untitled_32sceneCode.GDCoralBlockObjects2= [];
gdjs.Untitled_32sceneCode.GDYou_9595Win_9595TextObjects1= [];
gdjs.Untitled_32sceneCode.GDYou_9595Win_9595TextObjects2= [];


gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDCarbonObjects1Objects = Hashtable.newFrom({"Carbon": gdjs.Untitled_32sceneCode.GDCarbonObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDRedBlockObjects1Objects = Hashtable.newFrom({"RedBlock": gdjs.Untitled_32sceneCode.GDRedBlockObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDCarbonObjects1Objects = Hashtable.newFrom({"Carbon": gdjs.Untitled_32sceneCode.GDCarbonObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDCoralBlockObjects1Objects = Hashtable.newFrom({"CoralBlock": gdjs.Untitled_32sceneCode.GDCoralBlockObjects1});
gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Carbon"), gdjs.Untitled_32sceneCode.GDCarbonObjects1);
gdjs.copyArray(runtimeScene.getObjects("RedBlock"), gdjs.Untitled_32sceneCode.GDRedBlockObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDCarbonObjects1Objects, "PlatformerObject", gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDRedBlockObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDCarbonObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCarbonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCarbonObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.camera.setCameraX(runtimeScene, 10, "", 0);
}
{gdjs.evtTools.camera.setCameraY(runtimeScene, -10, "", 0);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Carbon"), gdjs.Untitled_32sceneCode.GDCarbonObjects1);
gdjs.copyArray(runtimeScene.getObjects("CoralBlock"), gdjs.Untitled_32sceneCode.GDCoralBlockObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDCarbonObjects1Objects, "PlatformerObject", gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDCoralBlockObjects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDCarbonObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCarbonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCarbonObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDCarbonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCarbonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDarkWoodPlancksBlockObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDarkWoodPlancksBlockObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBlueBlockObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBlueBlockObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDYellowBlockObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDYellowBlockObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCharcoalBlockObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCharcoalBlockObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGreyBlockObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGreyBlockObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRedBlockObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRedBlockObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGame_9595Over_9595TextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGame_9595Over_9595TextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCoralBlockObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCoralBlockObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDYou_9595Win_9595TextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDYou_9595Win_9595TextObjects2.length = 0;

gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);
gdjs.Untitled_32sceneCode.GDCarbonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCarbonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDarkWoodPlancksBlockObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDarkWoodPlancksBlockObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBlueBlockObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBlueBlockObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDYellowBlockObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDYellowBlockObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCharcoalBlockObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCharcoalBlockObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGreyBlockObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGreyBlockObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRedBlockObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRedBlockObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGame_9595Over_9595TextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGame_9595Over_9595TextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCoralBlockObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCoralBlockObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDYou_9595Win_9595TextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDYou_9595Win_9595TextObjects2.length = 0;


return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
